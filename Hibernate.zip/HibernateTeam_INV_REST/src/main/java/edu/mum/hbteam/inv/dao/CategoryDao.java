package edu.mum.hbteam.inv.dao;


import edu.mum.hbteam.inv.domain.Category;


public interface CategoryDao extends GenericDao<Category>  
{
}

