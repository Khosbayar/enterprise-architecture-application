package edu.mum.hbteam.inv.domain;

public class BookStatus {
	public static final Long NEW_PUBLISHED = 1L;
	public static final Long IN_STOCK = 2L;
}
