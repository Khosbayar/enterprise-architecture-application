package edu.mum.hbteam.inv.dao;


import edu.mum.hbteam.inv.domain.Status;


public interface StatusDao extends GenericDao<Status>  
{
}

