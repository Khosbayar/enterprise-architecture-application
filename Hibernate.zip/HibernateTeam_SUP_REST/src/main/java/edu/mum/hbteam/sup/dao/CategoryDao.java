package edu.mum.hbteam.sup.dao;

import edu.mum.hbteam.sup.domain.Category;

public interface CategoryDao extends GenericDao<Category> {
      
}
